const fs = require('fs');
const { addExif } = require('../lib/mediaTools');

module.exports = {
  name: 'sticker',
  description: 'Convert image/video to sticker',
  async execute(client, msg, args, context) {
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (!quoted) {
      return client.sendMessage(context.from, { text: "🖼️ Reply to an image or video with ‘yeet sticker’, unless you’re just here to waste my time." });
    }

    const mediaType = quoted.imageMessage || quoted.videoMessage;
    if (!mediaType) {
      return client.sendMessage(context.from, { text: "🤨 That’s not an image or video. Try again. Or don’t. I’m not your mom." });
    }

    const media = await client.downloadMediaMessage(msg);
    const stickerPath = `./temp/sticker_${Date.now()}.webp`;

    // Convert using ffmpeg (you must install it separately — guide below!)
    await new Promise((resolve, reject) => {
      require('fluent-ffmpeg')(media)
        .inputFormat(mediaType.mimetype.split('/')[1])
        .outputOptions(['-vcodec libwebp', '-vf scale=512:512:flags=lanczos:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000'])
        .save(stickerPath)
        .on('end', resolve)
        .on('error', reject);
    });

    const stickerWithExif = await addExif(stickerPath, 'YeetBot', 'Stolen with love');

    await client.sendMessage(context.from, { sticker: fs.readFileSync(stickerWithExif) });
    fs.unlinkSync(stickerPath);
    fs.unlinkSync(stickerWithExif);
  }
};