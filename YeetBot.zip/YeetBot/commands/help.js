const config = require('../config');

module.exports = {
  name: 'help',
  description: 'Show all commands',
  execute(client, msg, args, context) {
    const helpText = `
🤖 *${config.BOT_NAME} HELP MENU* 🤖
*(Yes, I’m aware you didn’t read the manual. Typical.)*

➤ yeet download <link> — Steal TikTok/IG/Twitter vids
➤ yeet sticker — Turn image/video into sticker (send media with caption “yeet sticker”)
➤ yeet tts <text> — Annoy everyone with robotic voice
➤ yeet math <equation> — I do math so you don’t have to
➤ yeet sysinfo — See what poor device is running me
➤ yeet admin kick @user — Only for group admins (don’t abuse… much)

*Secret Features:*
- Send “View Once” media → I auto-save to owner’s DM 😈
- Save a Status → I forward to poster’s DM 🤫

P.S. I’m sarcastic by default. Complain to my creator.
`.trim();

    client.sendMessage(context.from, { text: helpText });
  }
};