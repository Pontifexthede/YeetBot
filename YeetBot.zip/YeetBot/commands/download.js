const { downloadFromURL } = require('../lib/socialDownloader');

module.exports = {
  name: 'download',
  description: 'Download videos/images from TikTok, Instagram, Twitter, etc.',
  async execute(client, msg, args, context) {
    const url = args[0];
    if (!url) {
      return client.sendMessage(context.from, { text: "🔗 Gimme a link, genius. Example: yeet download https://tiktok.com/..." });
    }

    try {
      await client.sendMessage(context.from, { text: "⏳ Hold your horses... downloading your questionable content." });

      const filePath = await downloadFromURL(url);

      await client.sendMessage(context.from, {
        video: fs.readFileSync(filePath),
        caption: "🎉 Here’s your download. Don’t tell anyone I helped you."
      });

      fs.unlinkSync(filePath); // cleanup
    } catch (e) {
      await client.sendMessage(context.from, { text: `❌ Failed. Reason: ${e.message}` });
    }
  }
};