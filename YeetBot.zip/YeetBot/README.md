# 🚀 YEETBOT SETUP GUIDE (FOR BEGINNERS)

## ✅ STEP 1: Install Node.js
→ Go to https://nodejs.org → Download LTS → Install

## ✅ STEP 2: Install FFmpeg (needed for stickers/videos)
- **Windows**: https://www.gyan.dev/ffmpeg/builds/ → Download & extract → Add to PATH
- **Mac**: Open Terminal → `brew install ffmpeg`
- **Linux**: `sudo apt update && sudo apt install ffmpeg`

## ✅ STEP 3: Open Terminal / Command Prompt
Navigate to your YeetBot folder:
```bash
cd path/to/YeetBot