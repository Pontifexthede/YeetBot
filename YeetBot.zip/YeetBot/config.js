// CUSTOMIZE THIS TO MAKE YEETBOT YOURS!

module.exports = {
  BOT_NAME: "YeetBot",
  WELCOME_MESSAGE: "Hey there, gorgeous. 😏 I’m YeetBot — your sassy media thief & chaos assistant. Type ‘yeet help’ before I get bored.",
  PERSONALITY: "sarcastic", // Options: sarcastic, cheerful, professional, chaotic
  OWNER_NUMBER: "your_whatsapp_number_here", // e.g. "1234567890@s.whatsapp.net" ← we’ll fix this later!
};